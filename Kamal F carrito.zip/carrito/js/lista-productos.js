const listaProductos = [
    {
    id : 1, 
    nombre : "Disco Duro 1Tb",
    desc : "Disco Duro 1Tb para PC WD marca Western Digital",
    stock : 10,
    precioUnitario: 41980,
    img: "1tb.jpg"
},
{
    id : 2, 
    nombre : "Monitor Led ",
    desc : "SAMSUNG Monitor Samsung Led 21.5",
    stock : 35,
    precioUnitario: 89990,
    img: "msl215.jpg"
},
{
    id : 3, 
    nombre : "Teclado Gamer",
    desc : "LOGITECH Teclado Gamer mecanico RGB asdasd",
    stock : 5,
    precioUnitario: 51990,
    img: "tecladogamer.jpg"
},
{
    id : 4, 
    nombre : "Procesador i3",
    desc : "INTEL Procesador Intel® Core™ i3-",
    stock : 5,
    precioUnitario: 109990,
    img: "i3.jpg"
},
{
    id : 5, 
    nombre : "Tinta Magenta",
    desc : "EPSON Cartucho Epson Magenta",
    stock : 50,
    precioUnitario: 124270,
    img: "cartuchomagenta.jpg"
},
{
    id : 6, 
    nombre : "Audifono",
    desc : "JBL Audífono Deportivo JBL Fliphook™, FlexSoft™, Black/Yellow",
    stock : 70,
    precioUnitario: 15990,
    img: "jbldeportivo.jpg"
},
{
    id : 7, 
    nombre : "RTX 2060",
    desc : "SP LABS Utilizado en GameClub, PC Gamer SP Labs GeForce",
    stock : 35,
    precioUnitario: 999990,
    img: "rtx2060zotac.jpg"
},
{
    id : 8, 
    nombre : "Volante Gamer",
    desc : "LOGITECH Volante Logitech G293 TRUEFORCE para PS4",
    stock : 16,
    precioUnitario: 299990,
    img: "lgvolanteg923.png"
},
{
    id : 9, 
    nombre : "Procesador i5",
    desc : "INTEL Procesador Intel® Core™ i5-96645",
    stock : 15,
    precioUnitario: 178990,
    img: "i5.jpg"
},
{
    id : 10, 
    nombre : "GTX 1650",
    desc : "MSI Tarjeta de Video MSI GeForce GTX 1650 Super",
    stock : 32,
    precioUnitario: 249990,
    img: "gtx1650msi.jpg"
},
{
    id : 11, 
    nombre : "Silla Gamer",
    desc : "Silla Gamer Profesional Dragster GT400 Pink",
    stock : 25,
    precioUnitario: 219990,
    img: "sgamerdragster.png"
},
{
    id : 12, 
    nombre : "Controlador ELGATO",
    desc : "Controlador de Transmisión ELGATO Stream Deck 10GAA9901",
    stock : 65,
    precioUnitario: 149990,
    img: "elgato.jpg"
},
]
